import bpy
import itertools
import numpy as np
import sys
import pandas as pd
import matplotlib.pyplot as plt
from io import StringIO
import orjson


def normalize(data):
   return (data - np.min(data)) / (np.max(data) - np.min(data))

def read_from_json_file(filename):
   with open(filename) as f:
       data = orjson.loads(f.read())
   return data


''' 
read light source sd from database 
input: index of light source 0-311
return spectral distribution array 
'''
def readLight(index):
   data = read_from_json_file("light_db/db.json")
   data = pd.read_csv(StringIO(data[list(data.keys())[index]]['spectraldata']))

   light_spectral_data = data['relativeIntensity'].to_numpy()
   light_spectral_data = normalize(light_spectral_data)
   light_spectral_list = data['wavelength'].to_numpy()
   
#    print(len(light_spectral_data))
#    print(light_spectral_list)
   return light_spectral_list,light_spectral_data

''' 
read light source sd from database based on the reflectance curve
input: index of light source 0-311 and wavelength
return spectral distribution array 
'''
def readLightfromReflectance(index,wavelength):
   data = read_from_json_file("light_db/db.json")
   data = pd.read_csv(StringIO(data[list(data.keys())[index]]['spectraldata']))

   light_spectral_data = data['relativeIntensity'].to_numpy()
   light_spectral_data = normalize(light_spectral_data)
   light_spectral_list = data['wavelength'].to_numpy()
   sd = []
   for w in wavelength:
       for i in range(len(light_spectral_list)):
           if int(light_spectral_list[i]) == int(w):
               sd.append(light_spectral_data[i])
               break
   
   print(len(sd))
   print(sd)
   return sd

'''
Helping function for readReflectance
'''
def extract_wavelength_and_reflectance(df):
   df = df.replace("{", "")
   df = df.replace("}", "")
   df = df.split(",")
   data = np.zeros((len(df), 2))
   for i in range(len(df)):
       data[i, 0] = float(df[i].split(":")[0])
       data[i, 1] = float(df[i].split(":")[1]) / 100
   return data


''' 
read reflectance sd from database 
input: index of reflectance, your index should be minus 3 (Incorrect)
Modified: search by name (Case sensitive)
return spectral distribution array 
'''
def readReflectance(name):
   data = pd.read_csv("spectraldb.csv")
   for i in range(len(data)):
       if name == data.iloc[i]['Name']:
           data = data.iloc[i]['SCEMeasures']
           break
   data = extract_wavelength_and_reflectance(data)
   print(len(data))
   
   return data


def export_csv(node, filename):
   resnode = node.inputs["Results in"].links[0].from_node
   rl = resnode["reslists"]
   zrl = list(zip(*rl))
   if len(set(zrl[0])) > 1 and node.animated:
       resstring = (
           "".join(["{} {},".format(r[2], r[3])
                    for r in rl if r[0] == "All"]) + "\n")
       metriclist = list(
           zip(*[
               r.split() for ri, r in enumerate(zrl[4]) if zrl[0][ri] == "All"
           ]))
   else:
       resstring = ("".join([
           "{} {} {},".format(r[0], r[2], r[3]) for r in rl if r[0] != "All"
       ]) + "\n")
       metriclist = list(
           itertools.zip_longest(*[
               r.split() for ri, r in enumerate(zrl[4]) if zrl[0][ri] != "All"
           ],
                                 fillvalue=""))

   for ml in metriclist:
       resstring += "".join(["{},".format(m) for m in ml]) + "\n"

   resstring += "\n"

   with open("/results/" + filename,
             "a+") as csvfile:
       csvfile.write(resstring)


# sync wavelength to the min range in the list
# currently just simply return the first one in objs list
def syncWavelength(objs):
    w = []
    for o in objs.keys():
        re = readReflectance(str(objs[o]))
        for i in re:
            w.append(i[0])
        break

    return w



def calculate(lights, objs):
    # clear the csv document
    with open("/results/result.csv",
                "w+") as csvfile:
        pass
    
    wl = syncWavelength(objs)

    for index in range(len(wl)):
        # initialise light source spectrum and object reflectance
        for o in objs.keys():
            object_materail_name = bpy.data.objects[o].data.materials.values()[0].name
            re = readReflectance(str(objs[o]))
            objre = []
            for i in re:
               objre.append(i[1])

            bpy.data.materials[object_materail_name].vi_params.radcolour[0]=objre[index]



        for l in lights.keys():
            lightSource = bpy.data.objects[l]
            data = readLightfromReflectance(int(lights[l]),wl)
            lightSource.vi_params.ies_rgb[0]=data[index]

        
        nt = bpy.data.node_groups["NodeTree"]
        override = {"node": nt.nodes["LiVi Context"]}
        bpy.ops.node.liexport(override, "INVOKE_DEFAULT")
        override = {"node": nt.nodes["LiVi Geometry"]}
        bpy.ops.node.ligexport(override, "INVOKE_DEFAULT")
        override = {"node": nt.nodes["LiVi Simulation"]}
        bpy.ops.node.livicalc(override, "INVOKE_DEFAULT")
        result = nt.nodes["VI CSV Export"]
        export_csv(result, f"result.csv")

       
