bl_info = {
    # required
    'name': 'Spectral Simulation Addon',
    'blender': (2, 93, 0),
    'category': 'Import-Export',
    # optional
    'version': (1, 0, 0),
    'author': 'Jiawei Hu',
    'description': 'Spectral Simulation addon',
}

import bpy
import itertools
import numpy as np
import sys
import pandas as pd
import matplotlib.pyplot as plt
from io import StringIO
import orjson
from .SpecFunc import readReflectance,readLightfromReflectance,readLight,calculate

objs_sensor = {}
objs_light = {}
objs_material = {}

# Define string property.
class MyGroup(bpy.types.PropertyGroup):
    bpy.types.Scene.Selected_Obj = bpy.props.StringProperty(name='Selected_Obj')
    bpy.types.Scene.Object_Reflectance = bpy.props.StringProperty(name='Object_Reflectance')
    bpy.types.Scene.Light_sd = bpy.props.StringProperty(name='Light_sd')
    bpy.types.Scene.ObjTypes = bpy.props.EnumProperty(name='ObjTypes', items = (('OP1','Light',''),('OP2','Object',''),('OP3','Sensor','')))

'''
Define operator to change string property.
'''
last_selection = []
class UpdateStringOperator(bpy.types.Operator):
    bl_idname = "update.mystring" 
    bl_label = ""
    def invoke(self, context, event):
        global last_selection
        if bpy.context.selected_objects != last_selection:
            last_selection = bpy.context.selected_objects
            bpy.context.scene.Selected_Obj = bpy.context.selected_objects[0].name
        return {'FINISHED'}

'''
Calculate spectrum output and save it as csv file
'''
class Calculation(bpy.types.Operator):
    bl_idname = "calculate.spectrum" 
    bl_label = ""
    def invoke(self, context, event):
        calculate(objs_light,objs_material)

        return {'FINISHED'}

'''
Define operator to preview the lighting distribution or material reflectance.
'''
class PreviewOperator1(bpy.types.Operator):
    bl_idname = "preview.one" 
    bl_label = ""
    def invoke(self, context, event):
        re = readReflectance(str(bpy.context.scene.Object_Reflectance))
        x = []
        y = []
        for i in re:
            x.append(i[0])
            y.append(i[1])
        plt.plot(x,y)
        plt.title(str(bpy.context.scene.Object_Reflectance))
        plt.xlabel('Wavelength')
        plt.ylabel('Reflectance')
        plt.show()
        return {'FINISHED'}

class PreviewOperator2(bpy.types.Operator):
    bl_idname = "preview.two" 
    bl_label = ""
    def invoke(self, context, event):
        x,y = readLight(int(bpy.context.scene.Light_sd))
        plt.plot(x,y)
        # plt.title(str(bpy.context.scene.Light_sd))
        plt.xlabel('Wavelength')
        plt.ylabel('Relative Intensity')
        plt.show()
        return {'FINISHED'}

'''
Pop up windows to set up object reflectance
'''
class MessageBox1(bpy.types.Operator):
    bl_idname = "message.messagebox1"
    bl_label = ""
 
    # Execution after clicking "OK" button
    def execute(self, context):
        # Set the reflectance to the current selected object
        so = str(bpy.context.scene.Selected_Obj) 
        objs_material[so] = bpy.context.scene.Object_Reflectance
        return {'FINISHED'}
 
    def invoke(self, context, event):
        # show the correct content
        so = str(bpy.context.scene.Selected_Obj)    
        if so in objs_material.keys():
            bpy.context.scene.Object_Reflectance = objs_material[so]
        else:
            bpy.context.scene.Object_Reflectance = ''

        return context.window_manager.invoke_props_dialog(self, width = 400)
 
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(context.scene, "Object_Reflectance")

        row = layout.row()
        row.operator("preview.one", text="Preview")


'''
Pop up windows to set up light distribution
'''
class MessageBox2(bpy.types.Operator):
    bl_idname = "message.messagebox2"
    bl_label = ""
 
    # Execution after clicking "OK" button
    def execute(self, context):
        # Set the reflectance to the current selected object
        so = str(bpy.context.scene.Selected_Obj) 
        objs_light[so] = bpy.context.scene.Light_sd
        return {'FINISHED'}
 
    def invoke(self, context, event):
        # show the correct content
        so = str(bpy.context.scene.Selected_Obj)    
        if so in objs_light.keys():
            bpy.context.scene.Light_sd = objs_light[so]
        else:
            bpy.context.scene.Light_sd = ''
        return context.window_manager.invoke_props_dialog(self, width = 400)
 
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(context.scene, "Light_sd")

        row = layout.row()
        row.operator("preview.two", text="Preview")

'''
Pop up windows to set up sensor
'''
class MessageBox3(bpy.types.Operator):
    bl_idname = "message.messagebox3"
    bl_label = ""


    # Execution after clicking "OK" button
    def execute(self, context):
        # Set the reflectance to the current selected object
        so = str(bpy.context.scene.Selected_Obj) 
        objs_sensor[so] = 'sensor'
        return {'FINISHED'}
 
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width = 400)
 
    def draw(self, context):
        self.layout.label(text = "Setup Success!")


'''
Main Panel
'''
class Panel(bpy.types.Panel):
    
    bl_idname = 'Spectral_Simulation_panel'
    bl_label = 'Spectrum Panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VI-Spectrum"
    
    def draw(self, context):
        
        layout = self.layout
        split = layout.split(factor=0.7)
        col = split.column()
        col.prop(context.scene, "Selected_Obj")

        col = split.column()
        col.operator("update.mystring", text="Update")

        row = layout.row()
        row.prop(context.scene, "ObjTypes")

        row = layout.row()
        row = layout.row()
        
        # Show pop-up based on the object types
        if (str(bpy.context.scene.ObjTypes) == "OP2"):
            row.operator("message.messagebox1", text = "Setup")
        elif (str(bpy.context.scene.ObjTypes) == "OP1"):
            row.operator("message.messagebox2", text = "Setup")
        else:
            row.operator("message.messagebox3", text = "Setup")

        row = layout.row()
        row.operator("calculate.spectrum", text = "Calculate")


CLASSES = [
    Panel,
    UpdateStringOperator,
    MyGroup,
    MessageBox1,
    MessageBox2,
    MessageBox3,
    PreviewOperator1,
    PreviewOperator2,
    Calculation
]


def register():
    # print('registered') # just for debug
    for klass in CLASSES:
        bpy.utils.register_class(klass)

def unregister():
    # print('unregistered') # just for debug
    for klass in CLASSES:
        bpy.utils.unregister_class(klass)

if __name__ == '__main__':
    register()